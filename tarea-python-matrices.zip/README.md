# Tarea: Búsqueda y Ordenación en Arreglos Multidimensionales (Python)

Este repositorio contiene dos programas desarrollados en Python para la asignatura de programación.  

## Archivos

- `busqueda_matriz.py`: Busca un valor dentro de una matriz 3x3 e indica su posición si lo encuentra.
- `ordenacion_matriz.py`: Ordena una fila específica de una matriz 3x3 utilizando el algoritmo Bubble Sort.
- `.gitignore`: Evita subir archivos innecesarios de PyCharm.

## Ejecución

1. Clona este repositorio en tu computadora.
2. Abre el proyecto en **PyCharm** o ejecuta desde terminal con:

```bash
python busqueda_matriz.py
python ordenacion_matriz.py
```

3. Sigue las instrucciones que aparecerán en la consola.

## Ejemplo de uso

- En `busqueda_matriz.py` ingresa el número a buscar (ejemplo: `7`).
- En `ordenacion_matriz.py` ingresa el índice de la fila a ordenar (0, 1 o 2).

## Autor

Areil Bravo Manzano
