# busqueda_matriz.py
# Programa 1: Buscar un valor en una matriz 3x3

matrix = [
    [5, 2, 9],
    [1, 7, 4],
    [3, 8, 6]
]

def find_value(matrix, value):
    positions = []
    for i, row in enumerate(matrix):
        for j, val in enumerate(row):
            if val == value:
                positions.append((i, j))
    return positions

def print_matrix(m):
    for r in m:
        print(r)

def main():
    print("Matriz (3x3):")
    print_matrix(matrix)
    try:
        value = int(input("Introduce el valor a buscar (ej. 7): "))
    except ValueError:
        print("Entrada inválida. Introduce un número entero.")
        return

    positions = find_value(matrix, value)
    if positions:
        print(f"\nEl valor {value} fue ENCONTRADO en:")
        for (i, j) in positions:
            print(f" - Fila {i} columna {j} (índices 0-based) — Fila {i+1}, Columna {j+1} (1-based)")
    else:
        print(f"\nEl valor {value} NO se encontró en la matriz.")

if __name__ == "__main__":
    main()
