# ordenacion_matriz.py
# Programa 2: Ordenar una fila específica de una matriz 3x3 usando Bubble Sort

matrix = [
    [5, 2, 9],
    [1, 7, 4],
    [3, 8, 6]
]

def bubble_sort_row(matrix, row_index):
    row = matrix[row_index]
    n = len(row)
    for i in range(n - 1):
        for j in range(n - 1 - i):
            if row[j] > row[j + 1]:
                row[j], row[j + 1] = row[j + 1], row[j]
    # fila queda ordenada dentro de la matriz

def print_matrix(m):
    for r in m:
        print(r)

def main():
    print("Matriz original:")
    print_matrix(matrix)

    try:
        row_index = int(input("Introduce el índice de la fila a ordenar (0-2) — por ejemplo 1: "))
    except ValueError:
        print("Índice inválido. Debe ser un número entero entre 0 y 2.")
        return

    if row_index < 0 or row_index >= len(matrix):
        print("Índice fuera de rango. Usa 0, 1 o 2.")
        return

    print(f"\nOrdenando la fila {row_index}...")
    bubble_sort_row(matrix, row_index)

    print("\nMatriz con la fila ordenada:")
    print_matrix(matrix)

if __name__ == "__main__":
    main()
